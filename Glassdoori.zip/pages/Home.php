<?php
  include "./components/Header.php";
?>

<div class="home-page">
  <div class="container">
    <div class="banner">
      <div class="text">
        <h1>Your work people are here</h1>
      </div>
      <div class="content">
        <img alt="Banner1" src="<?php echo DOMAIN;?>/assets/images/new/banner1.svg" />
        <div class="login-type">
          <p>Create an account or sign in. By continuing, you agree to our <a href="#">Terms of Use</a> and <a href="#">Privacy Policy</a>.</p>
          <a href="/login" class="facebook">
            <span class="icon">
              <svg class="SVGInline-svg" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 12c0-6.627-5.373-12-12-12S0 5.373 0 12c0 5.99 4.388 10.954 10.125 11.854V15.47H7.078V12h3.047V9.356c0-3.007 1.792-4.668 4.533-4.668 1.312 0 2.686.234 2.686.234v2.953H15.83c-1.491 0-1.956.925-1.956 1.875V12h3.328l-.532 3.469h-2.796v8.385C19.612 22.954 24 17.99 24 12z" fill="#1877F2"></path>
              </svg>
            </span>
            <span class="label">Continue with Facebook</span>
          </a>
          <div id="or">or</div>
          <div class="input">
            <label>Enter Email</label>
            <input type="email" name="email" id="email" class="continue-email" autofocus />
            <span class="error">Please enter a valid email address</span>
          </div>
          <a href="#" class="continue continue-with-email">
            Continue with email
          </a>
        </div>
        <img alt="Banner2" src="<?php echo DOMAIN;?>/assets/images/new/banner2.svg" />
      </div>
    </div>
  </div>
</div>

<hr class="home-hr" />

<div class="container">
  <div class="get-ahead">
    <div class="information">
      <h4>Get ahead with Glassdoor</h4>
      <p>We're serving up trusted insights and anonymous conversation, so you'll have the goods you need to succeed.</p>
    </div>
    <div class="trio">
      <div class="item">
        <svg width="66" height="65" viewBox="0 0 66 65" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="32.609" cy="32.206" r="31.25" stroke="#000" stroke-width="1.5"></circle><path d="M23.234 42.475h-1.333c-.134 0-.134 0-.134-.133V30.875c0-.133 0-.133.134-.133h4.266v-1.467h-4.266c-.934 0-1.6.667-1.6 1.6v11.467c0 .933.666 1.6 1.6 1.6h1.333v-1.467ZM37.905 42.34c0 .133 0 .133-.133.133h-11.6v1.467c0 .8-.667 1.467-1.467 1.467h-1.467v1.467h1.467c1.6 0 2.933-1.2 2.933-2.8v-.134h10.267c.933 0 1.6-.666 1.6-1.6v-7.2h-1.467v7.2h-.133ZM45.1 17.54H29.232c-.934 0-1.6.667-1.6 1.6v11.467c0 .934.666 1.6 1.6 1.6h10.133c0 1.6 1.2 2.934 2.8 2.934h1.467v-1.467h-1.467a1.48 1.48 0 0 1-1.466-1.467v-1.466H29.233c-.134 0-.134 0-.134-.134V19.141c0-.134 0-.134.134-.134h15.866c.134 0 .134 0 .134.133v11.467c0 .134 0 .134-.133.134h-1.334v1.466H45.1c.933 0 1.6-.666 1.6-1.6V19.141c0-.934-.667-1.6-1.6-1.6Z" fill="#000"></path></svg>
        <p>Join your work community</p>
      </div>
      <div class="item">
        <svg width="66" height="65" viewBox="0 0 66 65" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="32.609" cy="32.206" r="31.25" stroke="#000" stroke-width="1.5"></circle><path d="M41.086 19.963h-4.613v-1.585c0-1.73-1.441-3.171-3.171-3.171-1.73 0-3.171 1.441-3.171 3.17v3.172h10.955c.144 0 .144.144.144.144v23.64c0 .144-.144.144-.144.144H25.23c-.144 0-.144-.144-.144-.144v-23.64c0-.144.144-.144.144-.144h3.17v-1.442h-3.17c-1.01 0-1.73.721-1.73 1.73v23.64c0 1.009.72 1.73 1.73 1.73H40.94c1.01 0 1.73-.721 1.73-1.73V21.693c0-.865-.72-1.73-1.585-1.73Zm-9.514-1.585a1.6 1.6 0 0 1 1.586-1.586 1.6 1.6 0 0 1 1.585 1.586v1.585h-3.315v-1.585h.144Z" fill="#000"></path><path d="M26.816 37.55h12.685V23.278H26.816v14.27Zm11.1-12.83v11.244h-9.514V24.72h9.514ZM34.888 39.277h-8.216v1.585h8.216v-1.585ZM39.645 42.45H26.672v1.586h12.973v-1.585Z" fill="#000"></path></svg>
        <p>Find and apply to jobs</p>
      </div>
      <div class="item">
        <svg width="66" height="65" viewBox="0 0 66 65" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="32.609" cy="32.206" r="31.25" stroke="#000" stroke-width="1.5"></circle><path d="M34.163 43.939v-4.4h-5.866v4.4h1.466v-2.934h2.934v2.934h1.466ZM40.835 27.806c.4 0 .8.267.8.8v15.467H43.1v-15.6c0-1.2-.933-2.134-2.133-2.134h-.8v1.467h.667Z" fill="#000"></path><path d="M25.365 19.672c0-.4.267-.8.8-.8h10.267c.4 0 .8.267.8.8v24.133h1.466V19.672c0-1.2-.933-2.133-2.133-2.133h-10.4c-1.2 0-2.267.933-2.267 2.133v24.267h1.467V19.672Z" fill="#000"></path><path d="M35.633 21.937h-2.934v1.467h2.934v-1.467ZM29.77 21.937h-2.934v1.467h2.933v-1.467ZM29.77 26.34h-2.934v1.466h2.933v-1.467ZM29.77 30.738h-2.934v1.467h2.933v-1.467ZM29.77 35.138h-2.934v1.467h2.933v-1.467ZM35.633 26.34h-2.934v1.466h2.934v-1.467ZM35.633 30.738h-2.934v1.467h2.934v-1.467ZM35.633 35.138h-2.934v1.467h2.934v-1.467ZM45.232 45.406H21.766v1.466h23.466v-1.466Z" fill="#000"></path></svg>
        <p>Search company reviews</p>
      </div>
      <div class="item">
        <svg width="66" height="65" viewBox="0 0 66 65" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="32.609" cy="32.206" r="31.25" stroke="#000" stroke-width="1.5"></circle><path fill-rule="evenodd" clip-rule="evenodd" d="m45.5 26.954-.132.019a2.333 2.333 0 0 1-2.617-2.767h2.083c.366 0 .666.299.666.667v2.08Zm0 6.505H45.5a4.081 4.081 0 0 0-4.081 4.08H25.58a4.08 4.08 0 0 0-4.08-4.08v-5.172a4.081 4.081 0 0 0 4.08-4.081h15.838a4.081 4.081 0 0 0 4.081 4.081h.001v5.172Zm0 3.414c0 .369-.3.666-.666.666H42.75a2.752 2.752 0 0 1 2.748-2.746h.001v2.08Zm-23.333.666a.666.666 0 0 1-.667-.666v-2.08a2.751 2.751 0 0 1 2.747 2.746h-2.08ZM21.5 24.873c0-.368.299-.667.667-.667h2.08a2.75 2.75 0 0 1-2.747 2.748v-2.081Zm23.932-2H21.567c-.772 0-1.4.628-1.4 1.4V37.474a1.4 1.4 0 0 0 1.4 1.399H45.432c.772 0 1.402-.627 1.402-1.4v-13.2c0-.772-.63-1.4-1.402-1.4Zm-11.963 10.7a2.67 2.67 0 0 1-2.667-2.667 2.67 2.67 0 0 1 2.667-2.667 2.67 2.67 0 0 1 2.667 2.667 2.67 2.67 0 0 1-2.667 2.666Zm0-6.667a4 4 0 1 0 0 8 4 4 0 0 0 0-8ZM33.5 41.54h-9.333a1.333 1.333 0 0 1-1.333-1.333h21.333c0 .736-.597 1.333-1.333 1.333H33.5Z" fill="#000"></path></svg>
        <p>Compare salaries</p>
      </div>
    </div>
  </div>
</div>

<div class="start-search">
  <div class="container">
    <div class="information">
      <h4>Get ahead with Glassdoor</h4>
      <p>Need some inspiration? See what millions of people are looking for on Glassdoor today.</p>
    </div>

    <div class="expandable-list" id="expandable-list">
      <div class="">
        <div class="item">
          <h4>Popular Jobs</h4>
          <ul class="">
            <li><a href="" class="open-signin-modal">Social Media Manager</a></li>
            <li><a href="" class="open-signin-modal">Software Engineer</a></li>
            <li><a href="" class="open-signin-modal">Sales Representative</a></li>
            <li><a href="" class="open-signin-modal">Project Manager</a></li>
            <li><a href="" class="open-signin-modal">Account Manager</a></li>
          </ul>
        </div>
        <div class="item">
          <h4>Browse Jobs by City</h4>
          <ul class="">
            <li><a href="" class="open-signin-modal">New York</a></li>
            <li><a href="" class="open-signin-modal">Orlando</a></li>
            <li><a href="" class="open-signin-modal">Chicago</a></li>
            <li><a href="" class="open-signin-modal">Las Vegas</a></li>
            <li><a href="" class="open-signin-modal">San Diego</a></li>
          </ul>
        </div>
        <div class="item">
          <h4>Browse Jobs by Company</h4>
          <ul class="">
            <li><a href="" class="open-signin-modal">Meta</a></li>
            <li><a href="" class="open-signin-modal">Oracle</a></li>
            <li><a href="" class="open-signin-modal">Amazon</a></li>
            <li><a href="" class="open-signin-modal">Walmart</a></li>
            <li><a href="" class="open-signin-modal">Bank of America</a></li>
            <li><a href="" class="open-signin-modal">Microsoft</a></li>
          </ul>
        </div>
        <div class="item">
          <h4>Trending Job Searches</h4>
          <ul class="">
            <li><a href="" class="open-signin-modal">Social Media Manager at Meta</a></li>
            <li><a href="" class="open-signin-modal">Social Media Manager</a></li>
            <li><a href="" class="open-signin-modal">Remote Jobs at Meta</a></li>
            <li><a href="" class="open-signin-modal">Work from home Jobs at Meta</a></li>
            <li><a href="" class="open-signin-modal">Remote Jobs in Asia</a></li>
            <li><a href="" class="open-signin-modal">Amazon Jobs in Seattle</a></li>
            <li><a href="" class="open-signin-modal">Meta Jobs in Asia</a></li>
          </ul>
        </div>
      </div>
      <div class="community">
        <h2>Your Community is Waiting</h2>
        <a class="signin open-signin-modal" href="#">Sign Up for Free</a>
      </div>
    </div>

    <div class="arrow-container">
      <button class="arrow" type="button">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" role="img" aria-describedby="chevron">
          <title id="chevron">Expand Links</title>
          <g fill="#008855" fill-rule="evenodd" transform="rotate(90 12.5 12)">
            <path d="M9.75 20.1l7.523-7.386a1 1 0 0 0 0-1.428L9.75 3.9c-.509-.5-1.324-.5-1.833 0a1.261 1.261 0 0 0 0 1.8l6.416 6.3-6.416 6.3a1.261 1.261 0 0 0 0 1.8c.509.5 1.324.5 1.833 0z"></path>
          </g>
        </svg>
      </button>
    </div>
  </div>
</div>

<div class="login-modal">
  <div class="content">
    <div class="close-button">
      <button type="button" class="close-signin-modal">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24" role="img" aria-live="polite" aria-hidden="false" class="CloseIcon">
          <path fill="currentColor" fill-rule="evenodd" d="M6.623 5.278a.95.95 0 1 0-1.345 1.345L10.656 12l-5.378 5.377a.95.95 0 1 0 1.345 1.345L12 13.344l5.377 5.378a.95.95 0 0 0 1.345-1.345L13.344 12l5.378-5.377a.95.95 0 0 0-1.345-1.345L12 10.656 6.623 5.278Z" clip-rule="evenodd"></path>
        </svg>
      </button>
    </div>
    <h2>Create an Account or Sign In.</h2>
    <div class="login-type">
      <p>Create an account or sign in. By continuing, you agree to our <a href="#" >Terms of Use</a> and <a href="#">Privacy Policy</a>.</p>
      <a href="/login" class="facebook">
        <span class="icon">
          <svg class="SVGInline-svg" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M24 12c0-6.627-5.373-12-12-12S0 5.373 0 12c0 5.99 4.388 10.954 10.125 11.854V15.47H7.078V12h3.047V9.356c0-3.007 1.792-4.668 4.533-4.668 1.312 0 2.686.234 2.686.234v2.953H15.83c-1.491 0-1.956.925-1.956 1.875V12h3.328l-.532 3.469h-2.796v8.385C19.612 22.954 24 17.99 24 12z" fill="#1877F2"></path>
          </svg>
        </span>
        <span class="label">Continue with Facebook</span>
      </a>
      <div id="or">or</div>
      <div class="input">
        <label>Enter Email</label>
        <input type="email" name="email" class="continue-email-modal" id="email" autofocus />
        <span class="error">Please enter a valid email address.</span>
      </div>
      <a href="/login" class="continue continue-with-email-modal">
        Continue with email
      </a>
    </div>
  </div>
</div>

<?php
  include "./components/Footer.php";
?>