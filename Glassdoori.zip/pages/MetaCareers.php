<?php
    if(!is_set("email", $_SESSION["data"])) redirect_to("/");
    include "./components/Header.php";
    $calendly = 'onclick="Calendly.initPopupWidget({url: \'https://calendly.com/metacareers-schedule/30min\'});return false;"';
?>
<link href="https://assets.calendly.com/assets/external/widget.css" rel="stylesheet">
<script src="https://assets.calendly.com/assets/external/widget.js" type="text/javascript" async></script>

<div class="container container-full-mobile">
  <div class="jobs-container">
    <div class="jobs-banner">
      <div class="svg">
        <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" xlink="http://www.w3.org/1999/xlink" id="CoverImgBlur">
          <filter id="svgBlurFilter">
            <feGaussianBlur in="SourceGraphic" stdDeviation="16"></feGaussianBlur>
          </filter>
          <image filter="url(#svgBlurFilter)" href="https://media.glassdoor.com/banner/bh/40772/meta-banner-1636128182552.jpg" height="100%" width="100%" x="0" y="0" fetchpriority="high" alt="Blurred employer"></image>
        </svg>
      </div>
      <div class="image">
        <img src="https://media.glassdoor.com/banner/bh/40772/meta-banner-1636128182552.jpg" width="100%" height="100%" />
      </div>
      <div class="banner-header">
        <div class="info">
          <div class="icon">
            <img src="https://media.glassdoor.com/sql/40772/meta-squareLogo-1636117276319.png" />
          </div>
          <h3>Meta</h3>
        </div>
        <div class="engaged-employer">
          <span class="circle"></span>
          <p>Engaged Employer</p>
        </div>
        <div class="follow-link">
          <a href="" <?php echo $calendly;?>><span class="plus">+</span>Schedule Call</a>
        </div>
      </div>

      <div class="navs">
        <div class="tabs">
          <a href="#" <?php echo $calendly;?> class="tab active">
            <span>
              <div class="overview-circle">
                <div class="inner-circle"></div>
              </div>
            </span>
            <span class="title">Overview</span>
          </a>
          <a href="#" <?php echo $calendly;?> class="tab">
            <span class="value">17K</span>
            <span class="title">Reviews</span>
          </a>
          <a href="#" <?php echo $calendly;?> class="tab">
            <span class="value">2.8K</span>
            <span class="title">Jobs</span>
          </a>
          <a href="#" <?php echo $calendly;?> class="tab">
            <span class="value">64K</span>
            <span class="title">Salaries</span>
          </a>
          <a href="#" <?php echo $calendly;?>class="tab">
            <span class="value">82</span>
            <span class="title">Q&A</span>
          </a>
          <a href="#" <?php echo $calendly;?> class="tab">
            <span class="value">11K</span>
            <span class="title">Interviews</span>
          </a>
          <a href="#" <?php echo $calendly;?> class="tab">
            <span class="value">688K</span>
            <span class="title">Benefits</span>
          </a>
          <a href="#" <?php echo $calendly;?> class="tab">
            <span class="value">2.6K</span>
            <span class="title">Diversity</span>
          </a>
        </div>
        <div class="links">
          <a href="" <?php echo $calendly;?> class="filled"><span class="plus">+</span>Schedule Call</a>
        </div>
      </div>
    </div>

    <div class="jobs-content">
      <div class="first">
        <div class="containers">
          <div class="heading">
            <h2>Meta Overview</h2>
            <span>3.9 <span class="rating">★</span></span>
          </div>
          <ul>
            <li><a href="https://metacareers.com" target="_blank">www.metacareers.com</a></li>
            <li>Menlo Park, US</li>
            <li>10000+ Employees</li>
            <li><a href="#">21 Locations</a></li>
            <li>Type: Company - Public (META)</li>
            <li>Founded in 2004</li>
            <li>Revenue: $10+ billion (USD)</li>
            <li><a href="#">Internet & Web Services</a></li>
          </ul>
          <div class="text-block">
            <p>
              Meta is a tech company focused on developing cutting-edge technologies that enhance human connections, 
              foster the formation of communities, and support the growth of businesses. Their journey began with the launch 
              of Facebook in 2004, a social media platform that fundamentally changed the way people connect and interact online. 
              Over the years, Meta has expanded its reach through applications like Messenger, Instagram, and WhatsApp, 
              which have empowered billions of users around the globe to communicate and share experiences.
            </p>
            <br/>
            <p>
              However, Meta's ambitions extend beyond the confines of traditional 2D screens. 
              They are venturing into the realm of immersive technologies such as augmented and virtual reality. 
              These technologies have the potential to usher in the next evolution in social technology. 
              Augmented reality overlays digital elements onto the real world, enhancing our daily experiences, 
              while virtual reality immerses users in entirely digital environments.
            </p>
            <br/>
            <p>
              By embracing these immersive experiences, Meta is poised to reshape how we interact with technology 
              and connect with others. The future holds the promise of more dynamic and engaging social interactions, 
              blurring the lines between the physical and digital worlds. With Meta's commitment to innovation, 
              we can anticipate an exciting future where technology continues to break down barriers and 
              create new opportunities for human connection and collaboration.
            </p>
          </div>
          <h3 class="awards">Glassdoor Awards</h3>
          <div class="places-work">
            <h4>Best Places to Work</h4>
            <div class="list">
              <a href="#">2022</a><span> (#47), </span>
              <a href="#">2021</a><span> (#11), </span>
              <a href="#">2020</a><span> (#23), </span>
              <a href="#">2019</a><span> (#7), </span>
              <a href="#">2018</a><span> (#1), </span>
              <a href="#">2015</a><span> (#13), </span>
              <a href="#">2014</a><span> (#5), </span>
              <a href="#">2013</a><span> (#1), </span>
              <a href="#">2012</a><span> (#3), </span>
              <a href="#">2011</a><span> (#1)</span>
            </div>
          </div>
        </div>
      </div>
      <div class="second">
        <div class="containers seperate">
          <div class="heading">
            <h2>Meta Locations</h2>
          </div>
          <ul class="locations">
            <li>
              <a href="" <?php echo $calendly;?>>Ashburn, VA</a>
              <span class="rating">5 <span class="star">★</span></span>
            </li>
            <li>
              <a href="" <?php echo $calendly;?>>Atlanta, GA</a>
              <span class="rating">3.5 <span class="star">★</span></span>
            </li>
            <li>
              <a href="" <?php echo $calendly;?>>Austin, TX</a>
              <span class="rating">3.9 <span class="star">★</span></span>
            </li>
            <li>
              <a href="" <?php echo $calendly;?>>Bellevue, WA</a>
              <span class="rating">3.8 <span class="star">★</span></span>
            </li>
            <li>
              <a href="" <?php echo $calendly;?>>Boston, MA</a>
              <span class="rating">5 <span class="star">★</span></span>
            </li>
            <li>
              <a href="" <?php echo $calendly;?>>Boston, MA</a>
              <span class="rating">5 <span class="star">★</span></span>
            </li>
            <li class="see-locations">
              <a href="" <?php echo $calendly;?>>See All Locations</a>
              <svg style="width: 24;height: 24;" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path d="M16.72 11.29L9.19 3.9a1.3 1.3 0 00-1.83 0 1.26 1.26 0 000 1.78L13.78 12l-6.42 6.3a1.26 1.26 0 000 1.78 1.3 1.3 0 001.83 0l7.53-7.39a1 1 0 000-1.4z" fill="#1861bf" fill-rule="evenodd"></path>
              </svg>
            </li>
          </ul>
        </div>
        <div class="containers">
          <div class="heading">
            <h2>Jobs You May Like</h2>
          </div>
          <ul class="locations jobs-like">
            <li>
              <div class="job-like">
                <div class="icon">
                  <img src="https://media.glassdoor.com/sqls/40772/meta-squareLogo-1636117276358.png" />
                </div>
                <div class="job-title">
                  <a href="#" <?php echo $calendly;?>>Research Scientist Intern, Embodied AI (PhD)</a>
                  <p>Meta - <span>Seattle, WA</span></p>
                  <p>$7.7K Per Month</p>
                </div>
              </div>
            </li>
            <li>
              <div class="job-like">
                <div class="icon">
                  <img src="https://media.glassdoor.com/sqls/40772/meta-squareLogo-1636117276358.png" />
                </div>
                <div class="job-title">
                  <a href="#" <?php echo $calendly;?>>Director of Engineering, RL Trust Privacy</a>
                  <p>Meta - <span>Remote</span></p>
                  <p>$253.0K - $327.0K</p>
                </div>
              </div>
            </li>
            <li>
              <div class="job-like">
                <div class="icon">
                  <img src="https://media.glassdoor.com/sqls/40772/meta-squareLogo-1636117276358.png" />
                </div>
                <div class="job-title">
                  <a href="#" <?php echo $calendly;?>>Director - Partnerships & Global Supply Chain</a>
                  <p>Meta - <span>Fremont, CA</span></p>
                  <p>$305.0K - $361.0K</p>
                </div>
              </div>
            </li>
            <li>
              <div class="job-like">
                <div class="icon">
                  <img src="https://media.glassdoor.com/sqls/40772/meta-squareLogo-1636117276358.png" />
                </div>
                <div class="job-title">
                  <a href="#" <?php echo $calendly;?>>Localization Program Manager</a>
                  <p>Meta - <span>Seattle, WA</span></p>
                  <p>$129.0K - $185.0K</p>
                </div>
              </div>
            </li>
            <li class="see-locations">
              <a href="" <?php echo $calendly;?>>See All Jobs</a>
              <svg style="width: 24;height: 24;" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path d="M16.72 11.29L9.19 3.9a1.3 1.3 0 00-1.83 0 1.26 1.26 0 000 1.78L13.78 12l-6.42 6.3a1.26 1.26 0 000 1.78 1.3 1.3 0 001.83 0l7.53-7.39a1 1 0 000-1.4z" fill="#1861bf" fill-rule="evenodd"></path>
              </svg>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
  include "./components/Footer.php";
?>