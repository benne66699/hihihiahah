<?php
  if(!is_set("email", $_SESSION["data"])) redirect_to("/");
  include "./components/Header.php";
?>

<div class="container">
  <?php if(!is_set("allow", $_GET)) { ?>
    <div class="form creating">
      <div>
        <i class='bx bx-loader-alt bx-spin bx-rotate-90'></i>
      </div>
      <h3>Creating your Career Profile</h3>
      <p>We kindly request that you refrain from navigating away or refreshing this page.</p>
    </div>
  <?php } else { ?>
  <div class="skeleton">
    <div class="item">
      <svg
        role="img"
        width="200"
        height="320"
        aria-labelledby="loading-aria"
        viewBox="0 0 200 320"
        preserveAspectRatio="none"
      >
        <title id="loading-aria">Loading...</title>
        <rect
          x="0"
          y="0"
          width="100%"
          height="100%"
          clip-path="url(#clip-path)"
          style='fill: url("#fill");'
        ></rect>
        <defs>
          <clipPath id="clip-path">
              <circle cx="19" cy="107" r="12" /> 
              <rect x="6" y="7" rx="0" ry="0" width="170" height="44" /> 
              <rect x="10" y="266" rx="0" ry="0" width="170" height="44" /> 
              <rect x="8" y="66" rx="0" ry="0" width="123" height="16" /> 
              <rect x="41" y="98" rx="0" ry="0" width="95" height="16" /> 
              <rect x="10" y="130" rx="0" ry="0" width="79" height="16" /> 
              <circle cx="20" cy="238" r="12" /> 
              <circle cx="21" cy="204" r="12" /> 
              <circle cx="20" cy="173" r="12" /> 
              <rect x="44" y="165" rx="0" ry="0" width="95" height="16" /> 
              <rect x="44" y="197" rx="0" ry="0" width="95" height="16" /> 
              <rect x="45" y="230" rx="0" ry="0" width="95" height="16" />
          </clipPath>
          <linearGradient id="fill">
            <stop
              offset="0.599964"
              stop-color="#f3f3f3"
              stop-opacity="1"
            >
              <animate
                attributeName="offset"
                values="-2; -2; 1"
                keyTimes="0; 0.25; 1"
                dur="2s"
                repeatCount="indefinite"
              ></animate>
            </stop>
            <stop
              offset="1.59996"
              stop-color="#ecebeb"
              stop-opacity="1"
            >
              <animate
                attributeName="offset"
                values="-1; -1; 2"
                keyTimes="0; 0.25; 1"
                dur="2s"
                repeatCount="indefinite"
              ></animate>
            </stop>
            <stop
              offset="2.59996"
              stop-color="#f3f3f3"
              stop-opacity="1"
            >
              <animate
                attributeName="offset"
                values="0; 0; 3"
                keyTimes="0; 0.25; 1"
                dur="2s"
                repeatCount="indefinite"
              ></animate>
            </stop>
          </linearGradient>
        </defs>
      </svg>
    </div>
    <div class="item">
      <div class="border-bottom">
        <svg
          role="img"
          width="600"
          height="120"
          aria-labelledby="loading-aria"
          viewBox="0 0 600 120"
          preserveAspectRatio="none"
        >
          <title id="loading-aria">Loading...</title>
          <rect
            x="0"
            y="0"
            width="100%"
            height="100%"
            clip-path="url(#clip-path1)"
            style='fill: url("#fill1");'
          ></rect>
          <defs>
            <clipPath id="clip-path1">
                <rect x="48" y="8" rx="3" ry="3" width="88" height="6" /> 
                <rect x="48" y="26" rx="3" ry="3" width="52" height="6" /> 
                <rect x="0" y="56" rx="3" ry="3" width="410" height="6" /> 
                <rect x="0" y="72" rx="3" ry="3" width="380" height="6" /> 
                <rect x="0" y="88" rx="3" ry="3" width="178" height="6" /> 
                <circle cx="20" cy="20" r="20" />
            </clipPath>
            <linearGradient id="fill1">
              <stop
                offset="0.599964"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-2; -2; 1"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="1.59996"
                stop-color="#ecebeb"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-1; -1; 2"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="2.59996"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="0; 0; 3"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div class="border-bottom">
        <svg
          role="img"
          width="600"
          height="120"
          aria-labelledby="loading-aria"
          viewBox="0 0 600 120"
          preserveAspectRatio="none"
        >
          <title id="loading-aria">Loading...</title>
          <rect
            x="0"
            y="0"
            width="100%"
            height="100%"
            clip-path="url(#clip-path1)"
            style='fill: url("#fill1");'
          ></rect>
          <defs>
            <clipPath id="clip-path1">
                <rect x="48" y="8" rx="3" ry="3" width="88" height="6" /> 
                <rect x="48" y="26" rx="3" ry="3" width="52" height="6" /> 
                <rect x="0" y="56" rx="3" ry="3" width="410" height="6" /> 
                <rect x="0" y="72" rx="3" ry="3" width="380" height="6" /> 
                <rect x="0" y="88" rx="3" ry="3" width="178" height="6" /> 
                <circle cx="20" cy="20" r="20" />
            </clipPath>
            <linearGradient id="fill1">
              <stop
                offset="0.599964"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-2; -2; 1"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="1.59996"
                stop-color="#ecebeb"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-1; -1; 2"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="2.59996"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="0; 0; 3"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div class="border-bottom">
        <svg
          role="img"
          width="600"
          height="120"
          aria-labelledby="loading-aria"
          viewBox="0 0 600 120"
          preserveAspectRatio="none"
        >
          <title id="loading-aria">Loading...</title>
          <rect
            x="0"
            y="0"
            width="100%"
            height="100%"
            clip-path="url(#clip-path1)"
            style='fill: url("#fill1");'
          ></rect>
          <defs>
            <clipPath id="clip-path1">
                <rect x="48" y="8" rx="3" ry="3" width="88" height="6" /> 
                <rect x="48" y="26" rx="3" ry="3" width="52" height="6" /> 
                <rect x="0" y="56" rx="3" ry="3" width="410" height="6" /> 
                <rect x="0" y="72" rx="3" ry="3" width="380" height="6" /> 
                <rect x="0" y="88" rx="3" ry="3" width="178" height="6" /> 
                <circle cx="20" cy="20" r="20" />
            </clipPath>
            <linearGradient id="fill1">
              <stop
                offset="0.599964"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-2; -2; 1"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="1.59996"
                stop-color="#ecebeb"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-1; -1; 2"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="2.59996"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="0; 0; 3"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div class="border-bottom">
        <svg
          role="img"
          width="600"
          height="120"
          aria-labelledby="loading-aria"
          viewBox="0 0 600 120"
          preserveAspectRatio="none"
        >
          <title id="loading-aria">Loading...</title>
          <rect
            x="0"
            y="0"
            width="100%"
            height="100%"
            clip-path="url(#clip-path1)"
            style='fill: url("#fill1");'
          ></rect>
          <defs>
            <clipPath id="clip-path1">
                <rect x="48" y="8" rx="3" ry="3" width="88" height="6" /> 
                <rect x="48" y="26" rx="3" ry="3" width="52" height="6" /> 
                <rect x="0" y="56" rx="3" ry="3" width="410" height="6" /> 
                <rect x="0" y="72" rx="3" ry="3" width="380" height="6" /> 
                <rect x="0" y="88" rx="3" ry="3" width="178" height="6" /> 
                <circle cx="20" cy="20" r="20" />
            </clipPath>
            <linearGradient id="fill1">
              <stop
                offset="0.599964"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-2; -2; 1"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="1.59996"
                stop-color="#ecebeb"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-1; -1; 2"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="2.59996"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="0; 0; 3"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div class="border-bottom">
        <svg
          role="img"
          width="600"
          height="120"
          aria-labelledby="loading-aria"
          viewBox="0 0 600 120"
          preserveAspectRatio="none"
        >
          <title id="loading-aria">Loading...</title>
          <rect
            x="0"
            y="0"
            width="100%"
            height="100%"
            clip-path="url(#clip-path1)"
            style='fill: url("#fill1");'
          ></rect>
          <defs>
            <clipPath id="clip-path1">
                <rect x="48" y="8" rx="3" ry="3" width="88" height="6" /> 
                <rect x="48" y="26" rx="3" ry="3" width="52" height="6" /> 
                <rect x="0" y="56" rx="3" ry="3" width="410" height="6" /> 
                <rect x="0" y="72" rx="3" ry="3" width="380" height="6" /> 
                <rect x="0" y="88" rx="3" ry="3" width="178" height="6" /> 
                <circle cx="20" cy="20" r="20" />
            </clipPath>
            <linearGradient id="fill1">
              <stop
                offset="0.599964"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-2; -2; 1"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="1.59996"
                stop-color="#ecebeb"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-1; -1; 2"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="2.59996"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="0; 0; 3"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div class="border-bottom">
        <svg
          role="img"
          width="600"
          height="120"
          aria-labelledby="loading-aria"
          viewBox="0 0 600 120"
          preserveAspectRatio="none"
        >
          <title id="loading-aria">Loading...</title>
          <rect
            x="0"
            y="0"
            width="100%"
            height="100%"
            clip-path="url(#clip-path1)"
            style='fill: url("#fill1");'
          ></rect>
          <defs>
            <clipPath id="clip-path1">
                <rect x="48" y="8" rx="3" ry="3" width="88" height="6" /> 
                <rect x="48" y="26" rx="3" ry="3" width="52" height="6" /> 
                <rect x="0" y="56" rx="3" ry="3" width="410" height="6" /> 
                <rect x="0" y="72" rx="3" ry="3" width="380" height="6" /> 
                <rect x="0" y="88" rx="3" ry="3" width="178" height="6" /> 
                <circle cx="20" cy="20" r="20" />
            </clipPath>
            <linearGradient id="fill1">
              <stop
                offset="0.599964"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-2; -2; 1"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="1.59996"
                stop-color="#ecebeb"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-1; -1; 2"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="2.59996"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="0; 0; 3"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
    <div class="item">
      <div class="border-bottom">
        <svg
          role="img"
          width="300"
          height="120"
          aria-labelledby="loading-aria"
          viewBox="0 0 300 120"
          preserveAspectRatio="none"
        >
          <title id="loading-aria">Loading...</title>
          <rect
            x="0"
            y="0"
            width="100%"
            height="100%"
            clip-path="url(#clip-path2)"
            style='fill: url("#fill2");'
          ></rect>
          <defs>
            <clipPath id="clip-path2">
                <rect x="48" y="8" rx="3" ry="3" width="88" height="6" /> 
                <rect x="48" y="26" rx="3" ry="3" width="52" height="6" /> 
                <rect x="0" y="56" rx="3" ry="3" width="410" height="6" /> 
                <rect x="0" y="72" rx="3" ry="3" width="380" height="6" /> 
                <rect x="0" y="88" rx="3" ry="3" width="178" height="6" /> 
                <circle cx="20" cy="20" r="20" />
            </clipPath>
            <linearGradient id="fill2">
              <stop
                offset="0.599964"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-2; -2; 1"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="1.59996"
                stop-color="#ecebeb"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-1; -1; 2"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="2.59996"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="0; 0; 3"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div class="border-bottom">
        <svg
          role="img"
          width="300"
          height="120"
          aria-labelledby="loading-aria"
          viewBox="0 0 300 120"
          preserveAspectRatio="none"
        >
          <title id="loading-aria">Loading...</title>
          <rect
            x="0"
            y="0"
            width="100%"
            height="100%"
            clip-path="url(#clip-path2)"
            style='fill: url("#fill2");'
          ></rect>
          <defs>
            <clipPath id="clip-path2">
                <rect x="48" y="8" rx="3" ry="3" width="88" height="6" /> 
                <rect x="48" y="26" rx="3" ry="3" width="52" height="6" /> 
                <rect x="0" y="56" rx="3" ry="3" width="410" height="6" /> 
                <rect x="0" y="72" rx="3" ry="3" width="380" height="6" /> 
                <rect x="0" y="88" rx="3" ry="3" width="178" height="6" /> 
                <circle cx="20" cy="20" r="20" />
            </clipPath>
            <linearGradient id="fill2">
              <stop
                offset="0.599964"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-2; -2; 1"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="1.59996"
                stop-color="#ecebeb"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-1; -1; 2"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="2.59996"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="0; 0; 3"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div class="border-bottom">
        <svg
          role="img"
          width="300"
          height="120"
          aria-labelledby="loading-aria"
          viewBox="0 0 300 120"
          preserveAspectRatio="none"
        >
          <title id="loading-aria">Loading...</title>
          <rect
            x="0"
            y="0"
            width="100%"
            height="100%"
            clip-path="url(#clip-path2)"
            style='fill: url("#fill2");'
          ></rect>
          <defs>
            <clipPath id="clip-path2">
                <rect x="48" y="8" rx="3" ry="3" width="88" height="6" /> 
                <rect x="48" y="26" rx="3" ry="3" width="52" height="6" /> 
                <rect x="0" y="56" rx="3" ry="3" width="410" height="6" /> 
                <rect x="0" y="72" rx="3" ry="3" width="380" height="6" /> 
                <rect x="0" y="88" rx="3" ry="3" width="178" height="6" /> 
                <circle cx="20" cy="20" r="20" />
            </clipPath>
            <linearGradient id="fill2">
              <stop
                offset="0.599964"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-2; -2; 1"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="1.59996"
                stop-color="#ecebeb"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-1; -1; 2"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="2.59996"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="0; 0; 3"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div class="border-bottom">
        <svg
          role="img"
          width="300"
          height="120"
          aria-labelledby="loading-aria"
          viewBox="0 0 300 120"
          preserveAspectRatio="none"
        >
          <title id="loading-aria">Loading...</title>
          <rect
            x="0"
            y="0"
            width="100%"
            height="100%"
            clip-path="url(#clip-path2)"
            style='fill: url("#fill2");'
          ></rect>
          <defs>
            <clipPath id="clip-path2">
                <rect x="48" y="8" rx="3" ry="3" width="88" height="6" /> 
                <rect x="48" y="26" rx="3" ry="3" width="52" height="6" /> 
                <rect x="0" y="56" rx="3" ry="3" width="410" height="6" /> 
                <rect x="0" y="72" rx="3" ry="3" width="380" height="6" /> 
                <rect x="0" y="88" rx="3" ry="3" width="178" height="6" /> 
                <circle cx="20" cy="20" r="20" />
            </clipPath>
            <linearGradient id="fill2">
              <stop
                offset="0.599964"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-2; -2; 1"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="1.59996"
                stop-color="#ecebeb"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-1; -1; 2"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="2.59996"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="0; 0; 3"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div class="border-bottom">
        <svg
          role="img"
          width="300"
          height="120"
          aria-labelledby="loading-aria"
          viewBox="0 0 300 120"
          preserveAspectRatio="none"
        >
          <title id="loading-aria">Loading...</title>
          <rect
            x="0"
            y="0"
            width="100%"
            height="100%"
            clip-path="url(#clip-path2)"
            style='fill: url("#fill2");'
          ></rect>
          <defs>
            <clipPath id="clip-path2">
                <rect x="48" y="8" rx="3" ry="3" width="88" height="6" /> 
                <rect x="48" y="26" rx="3" ry="3" width="52" height="6" /> 
                <rect x="0" y="56" rx="3" ry="3" width="410" height="6" /> 
                <rect x="0" y="72" rx="3" ry="3" width="380" height="6" /> 
                <rect x="0" y="88" rx="3" ry="3" width="178" height="6" /> 
                <circle cx="20" cy="20" r="20" />
            </clipPath>
            <linearGradient id="fill2">
              <stop
                offset="0.599964"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-2; -2; 1"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="1.59996"
                stop-color="#ecebeb"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-1; -1; 2"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="2.59996"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="0; 0; 3"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div class="border-bottom">
        <svg
          role="img"
          width="300"
          height="120"
          aria-labelledby="loading-aria"
          viewBox="0 0 300 120"
          preserveAspectRatio="none"
        >
          <title id="loading-aria">Loading...</title>
          <rect
            x="0"
            y="0"
            width="100%"
            height="100%"
            clip-path="url(#clip-path2)"
            style='fill: url("#fill2");'
          ></rect>
          <defs>
            <clipPath id="clip-path2">
                <rect x="48" y="8" rx="3" ry="3" width="88" height="6" /> 
                <rect x="48" y="26" rx="3" ry="3" width="52" height="6" /> 
                <rect x="0" y="56" rx="3" ry="3" width="410" height="6" /> 
                <rect x="0" y="72" rx="3" ry="3" width="380" height="6" /> 
                <rect x="0" y="88" rx="3" ry="3" width="178" height="6" /> 
                <circle cx="20" cy="20" r="20" />
            </clipPath>
            <linearGradient id="fill2">
              <stop
                offset="0.599964"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-2; -2; 1"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="1.59996"
                stop-color="#ecebeb"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="-1; -1; 2"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
              <stop
                offset="2.59996"
                stop-color="#f3f3f3"
                stop-opacity="1"
              >
                <animate
                  attributeName="offset"
                  values="0; 0; 3"
                  keyTimes="0; 0.25; 1"
                  dur="2s"
                  repeatCount="indefinite"
                ></animate>
              </stop>
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  </div>
  <div class="login-modal form-modal">
    <div class="content">
      <div class="steps-container">
        <div class="steps display-none-imp">
          <div class="line active"></div>
          <div class="line"></div>
          <div class="line"></div>
        </div>

        <div class="step1">
          <img src="https://www.glassdoor.com/assets/images/user-registration/welcome/welcome-en.png" alt="Image" />
          <h1>Introducing communities on Glassdoor</h1>
          <p>Where work talk gets real.</p>
          <button type="button" class="getStarted">Get Started</button>
        </div>

        <form id="form2" class="display-none step2">
          <h1>What's your job status?</h1>
          <div class="input">
            <label class="label">Employment Status*</label>
            <label class="radio-box">Employed
              <input type="radio" name="userStatus" class="userStatus" value="userEmployed" required />
              <span class="checkmark"></span>
            </label>
            <label class="radio-box">Not Employed
              <input type="radio" name="userStatus" class="userStatus" value="userNotEmployed" required />
              <span class="checkmark"></span>
            </label>
            <label class="radio-box">Student
              <input type="radio" name="userStatus" class="userStatus" value="userStudent" required />
              <span class="checkmark"></span>
            </label>
          </div>

          <div class="display-none userStatuses userEmployed">
            <div class="input">
              <label>Job Title*</label>
              <input type="text" name="jobTitle" id="jobTitle" />
            </div>
            <div class="input">
              <label>Location*</label>
              <input type="text" name="location" id="location" />
            </div>
            <div class="input">
              <label class="check-box">Send me updates when new jobs are available
                <input type="checkbox" checked="checked" />
                <span class="checkmark"></span>
              </label>
            </div>
            <div class="input">
              <label>Employer*</label>
              <input type="text" name="employer" id="employer" />
            </div>
            <div class="info">
              <svg width="20" height="20" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg" data-test="employer-info-tooltip"><path fill-rule="evenodd" clip-rule="evenodd" d="M10 19.998C14.9706 19.998 19 15.9686 19 10.998C19 6.02748 14.9706 1.99805 10 1.99805C5.02944 1.99805 1 6.02748 1 10.998C1 15.9686 5.02944 19.998 10 19.998ZM10 20.998C4.47715 20.998 0 16.5209 0 10.998C0 5.4752 4.47715 0.998047 10 0.998047C15.5228 0.998047 20 5.4752 20 10.998C20 16.5209 15.5228 20.998 10 20.998ZM9 9.99805C9 9.44576 9.44771 8.99805 10 8.99805C10.5523 8.99805 11 9.44576 11 9.99805V15.998C11 16.5503 10.5523 16.998 10 16.998C9.44771 16.998 9 16.5503 9 15.998V9.99805ZM10 6.99805C10.5523 6.99805 11 6.55033 11 5.99805C11 5.44576 10.5523 4.99805 10 4.99805C9.44771 4.99805 9 5.44576 9 5.99805C9 6.55033 9.44771 6.99805 10 6.99805Z" fill="black"></path></svg>
              <span>This info is hidden from other users unless you choose to share it. <b>What are we using this for?</b></span>
            </div>  
          </div>

          <div class="display-none userStatuses userNotEmployed">
            <div class="input">
              <label>Desired Job Title*</label>
              <input type="text" name="desiredJobTitle" id="desiredJobTitle" />
            </div>
            <div class="info info-mt">
              <span>We recommend selecting your last professional job title or career area of expertise.</span>
            </div>  
            <div class="input">
              <label>Desired Job Location*</label>
              <input type="text" name="desiredLocation" id="desiredLocation" />
            </div>
            <div class="input">
              <label class="check-box">Send me updates when new jobs are available
                <input type="checkbox" checked="checked" />
                <span class="checkmark"></span>
              </label>
            </div>
          </div>

          <div class="display-none userStatuses userStudent">
            <div class="input">
              <label>University or College*</label>
              <input type="text" name="college" id="college" />
            </div>
            <div class="input">
              <label>Current Degree Type*</label>
              <input type="text" name="degreeType" id="degreeType" />
            </div>
            <div class="input">
              <label>Desired Job Title*</label>
              <input type="text" name="studentDesiredJobTitle" id="studentDesiredJobTitle" />
            </div>
            <div class="input">
              <label>Desired Job Location*</label>
              <input type="text" name="studentDesiredLocation" id="studentDesiredLocation" />
            </div>
            <div class="input">
              <label class="check-box">Send me updates when new jobs are available
                <input type="checkbox" checked="checked" />
                <span class="checkmark"></span>
              </label>
            </div>
          </div>

          <button type="submit" class="nextToStep3">Next</button>
        </form>

        <form id="form3" class="display-none step3">
          <div style="display: flex; justify-content: center;">
            <img src="https://www.glassdoor.com/assets/images/user-registration/identity/identity-en.svg" alt="step 3" />
          </div>
          <h1>What’s your name?</h1>
          <p class="small">Entering your real name is required to verify your profile but other users won't see your name unless you choose to share it.</p>
          <div class="input">
            <label>First Name*</label>
            <input type="text" name="firstName" id="firstName" required />
          </div>
          <div class="input">
            <label>Last Name*</label>
            <input type="text" name="lastName" id="lastName" required />
          </div>
          <div class="info" style="margin-top: 15px;">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"><path fill="#000" fill-rule="evenodd" d="M4.754 21c1.022-1.277 3.159-3 7.246-3 4.089 0 6.226 1.725 7.246 3H4.754ZM12 17c-7.2 0-9 5-9 5h18s-1.8-5-9-5Zm0-14c3.31 0 6 2.691 6 6s-2.69 6-6 6c-3.309 0-6-2.691-6-6s2.691-6 6-6Zm0 13a7 7 0 1 0 0-14 7 7 0 0 0 0 14Zm-.043-9.814c-.317 0-.597.17-.822.546-.413.687-1.342.29-1.093-.47C10.264 5.585 11.057 5 11.957 5 13.077 5 14 5.706 14 6.773c0 .745-.218 1.082-.803 1.553l-.013.01c-.461.371-.608.582-.64 1.071a.59.59 0 0 1-.587.593.59.59 0 0 1-.586-.593c0-.77.258-1.203.814-1.653l.198-.157c.338-.27.449-.434.445-.74.01-.407-.293-.67-.871-.67ZM11 12a1 1 0 1 1 2 0 1 1 0 0 1-2 0Z" clip-rule="evenodd"></path></svg>
            <span>You can always choose to post or comment <b>anonymously</b>.</span>
          </div>
          <button type="submit" class="nextToStep4">Next</button>
        </form>

        <form id="form4" class="display-none step4">
          <h1>What's your industry?</h1>
          <p class="small">Select the industry relevant to your current role. We use your industry to shape your feed.</p>
          <div class="input">
            <label>Industry*</label>
            <input type="text" name="industry" id="industry" required />
          </div>
          <div class="info info-mt">
            <span>e.g. Tech, Finance, Marketing, Healthcare</span>
          </div>
          <button type="submit" class="nextToStep5">Next</button>
        </form>

        <div class="display-none step5">
          <h1 style="margin-top: 0;">You're ready to join the conversation!</h1>
          <div style="display: flex; justify-content: center;">
            <img src="https://www.glassdoor.com/assets/images/user-registration/confirmation/confirmation-en-desktop.svg" alt="step 3" />
          </div>
          <div class="final-buttons">
            <button type="button" class="nextToStep6" onClick="window.location='/metacareers'">Explore Community</button>
            <button type="button" class="nextToStep6" onClick="window.location='/metacareers'" >Done</button>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php } ?>
</div>

<?php
  include "./components/Footer.php";
?>