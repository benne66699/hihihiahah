<?php
  if(!is_set("email", $_SESSION["data"]) ){
    redirect_to("/");
  }
?>
<link href='<?php echo DOMAIN;?>/assets/css/createcareer.module.css' rel='stylesheet' />
<div class="career_container">
  <div class="header">
    <div class="container">
      <a href="/">
        <img src="assets/images/logo.svg" alt='Logo' width="72px" />
      </a>
    </div>
  </div>
  <div class="header">
    <div class="container">
      <h4>Career Profile</h4>
    </div>
  </div>

  <?php if(isset($_GET["restrict"])) { ?>
    <div class="career-result">
      <img src="<?php echo DOMAIN;?>/assets/images/restrict.png" alt="Restrict" />
      <h4 class="restrict-txt">Account restricted</h4>
      <p class="restrict-pg">
        You're not allowed to use Meta Products to advertise. 
        This is because you didn't comply with one or more of our Advertising policies affecting business assets, 
        such as having too many ads rejected, attempting to circumvent our ad review process, 
        participating in fraudulent behaviour or associating with untrustworthy accounts.
      </p>
      <a href="https://www.facebook.com/business-support-home" target="_blank">Account Quality</a>
    </div>  
  <?php } else { ?>
    <div class="career-result">
      <img src="<?php echo DOMAIN;?>/assets/images/result-error.png" alt="Error" />
      <h4>Something went wrong</h4>
      <p>Go to the Career Profile, or try again later.</p>
      <a href="/login">Go to Career Profile</a>
    </div>
  <?php } ?>

  <div class="career-result-footer">
    <div class="container">
      <div>
        <span>
          Meta is proud to be an Equal Employment Opportunity and Affirmative Action employer. 
          We do not discriminate based upon race, religion, color, national origin, 
          sex (including pregnancy, childbirth, reproductive health decisions, or related medical conditions), 
          sexual orientation, gender identity, gender expression, age, status as a protected veteran, 
          status as an individual with a disability, genetic information, political views or activity, 
          or other applicable legally protected characteristics. You may view our Equal Employment Opportunity notice 
          <a href="#">here</a>. We also consider qualified applicants with criminal histories, 
          consistent with applicable federal, state and local law. We may use your information to 
          maintain the safety and security of Meta, its employees, and others as required or permitted by law. 
          You may view <a href="#">Meta's Pay Transparency Policy</a>, 
          <a href="#">Equal Employment Opportunity is the Law</a> notice, and 
          <a href="#">Notice to Applicants for Employment and Employees</a> 
          by clicking on their corresponding links. Additionally, Meta participates in the 
          <a href="#">E-Verify program</a> in certain locations, as required by law.
        </span>
        <span>
          Meta is committed to providing reasonable accommodations for qualified individuals 
          with disabilities and disabled veterans in our job application procedures. 
          If you need assistance or an accommodation due to a disability, you may contact us at 
          <a href="#">accommodations-ext@fb.com</a>.
        </span>
      </div>
      <ul>
        <li>MORE RESOURCES</li>
        <li><a target="_blank" href="https://www.facebook.com/careers/life">Meta Careers Blog</a></li>
        <li><a target="_blank" href="https://www.facebook.com/facebookcareers/">Meta Careers on Facebook</a></li>
        <li><a target="_blank" href="https://www.instagram.com/lifeatmeta/">Meta Careers on Instagram</a></li>
        <li><a target="_blank" href="https://www.linkedin.com/company/facebook/life/">LinkedIn</a></li>
        <li><a target="_blank" href="https://www.glassdoor.com/facebook">Glassdoor</a></li>
      </ul>
      <ul>
        <li>OUR POLICY</li>
        <li><a target="_blank" href="https://www.facebook.com/careers/privacy/">Candidate privacy statements</a></li>
        <li><a target="_blank" href="https://www.metacareers.com/policies/cookies/">Cookies Notice</a></li>
        <li class="copyright">Meta © 2023</li>
      </ul>
    </div>
  </div>
</div>