<div class="footer">
  <div class="topFooter">
    <a href="#">English (UK)</a>
    <a href="#">Deutsch</a>
    <a href="#">Türkçe</a>
    <a href="#">Српски</a>
    <a href="#">Français (France)</a>
    <a href="#">Italiano</a>
    <a href="#">Bosanski</a>
    <a href="#">Svenska</a>
    <a href="#">Español</a>
    <a href="#">Português (Brasil)</a>
  </div>
  <div class="bottomFooter">
    <a href="#">Sign Up</a>
    <a href="#">Log in</a>
    <a href="#">Messenger</a>
    <a href="#">Facebook Lite</a>
    <a href="#">Watch</a>
    <a href="#">Places</a>
    <a href="#">Games</a>
    <a href="#">Marketplace</a>
    <a href="#">Meta Pay</a>
    <a href="#">Oculus</a>
    <a href="#">Portal</a>
    <a href="#">Instagram</a>
    <a href="#">Bulletin</a>
    <a href="#">Fundraisers</a>
    <a href="#">Services</a>
    <a href="#">Voting Information Centre</a>
    <a href="#">Privacy Policy</a>
    <a href="#">Privacy Center</a>
    <a href="#">Groups</a>
    <a href="#">About</a>
    <a href="#">Create ad</a>
    <a href="#">Create Page</a>
    <a href="#">Developers</a>
    <a href="#">Careers</a>
    <a href="#">Cookies</a>
    <a href="#">AdChoices</a>
    <a href="#">Terms</a>
    <a href="#">Help</a>
    <a href="#">Contact uploading and non-users</a>
  </div>
  <span>Meta © 2023</span>
</div> 