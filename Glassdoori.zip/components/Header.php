<link href='<?php echo DOMAIN;?>/assets/css/style.css' rel='stylesheet' />

<header>
  <div class="container">
    <div class="header-container">
      <a href="/">
        <svg xmlns="http://www.w3.org/2000/svg" width="120" height="36" fill="none" role="img">
          <path fill="#00A264" fill-rule="evenodd" d="M115.399 14.355h4.539c.034 0 .062-.03.062-.067V9.812c-.001-1.094-.363-1.984-1.096-2.606-.674-.572-1.686-.917-3.039-.985-.034-.002-.062.027-.062.063v1.688c0 .033.025.06.056.063 1.187.083 2.09.466 2.09 1.8l-2.55.001c-.034 0-.062.03-.062.067v4.386c0 .036.028.066.062.066Zm-98.18 3.623h-5.504c-.086 0-.141.077-.141.153v2.956c0 .093.07.153.141.153h1.955v2.38c0 1.77-.432 2.72-1.955 2.72-1.272 0-2.175-.771-2.175-3.169V16.26c0-2.296.684-3.372 2.199-3.372 1.366 0 1.923.839 1.923 2.406v.89c0 .093.071.152.142.152h3.384c.086 0 .141-.076.141-.152V15.14c.031-3.718-1.947-5.684-5.527-5.684s-5.912 2.127-5.912 6.6v7.395c0 4.405 2.716 6.32 5.731 6.32 3.376 0 5.731-1.33 5.731-6.252v-5.397a.147.147 0 0 0-.133-.152h-.008.008v.008Zm10.536 7.876h-5.292V9.979c0-.094-.07-.153-.141-.153h-3.33c-.086 0-.14.076-.14.153v19.289c0 .093.07.152.14.152h8.755c.086 0 .141-.076.141-.152v-3.253c0-.093-.07-.153-.141-.153h.008v-.008Zm49.73-9.748c0-4.447 2.284-6.616 5.778-6.616 3.447 0 5.763 2.177 5.747 6.616v7.048c0 4.507-2.143 6.582-5.747 6.582s-5.778-2.033-5.778-6.582v-7.048Zm5.778 10.25c1.46 0 2.065-1.067 2.065-3.337v-6.752c0-2.27-.589-3.371-2.065-3.371s-2.065 1.143-2.065 3.371v6.752c0 2.279.605 3.337 2.065 3.337ZM96.195 9.49c-3.494 0-5.779 2.169-5.779 6.616v7.048c0 4.55 2.175 6.582 5.779 6.582s5.747-2.075 5.747-6.582v-7.048c.016-4.439-2.3-6.616-5.747-6.616ZM98.26 23.02c0 2.27-.605 3.337-2.065 3.337s-2.065-1.059-2.065-3.337v-6.752c0-2.228.589-3.371 2.065-3.371s2.065 1.1 2.065 3.371v6.752ZM65.285 9.82h4.993v.017c3.376 0 5.92 1.855 5.92 6.43v6.718c0 4.532-2.481 6.43-5.96 6.43h-4.953c-.071 0-.142-.06-.142-.153V9.99c0-.085.055-.17.142-.17Zm4.797 16.028c1.507 0 2.45-1.034 2.45-3.448l.007.008v-5.887c0-2.44-.989-3.423-2.489-3.423h-1.374v12.75h1.406ZM47.078 9.456h-.055c-3.439 0-5.252 2.118-5.252 5.295 0 3.307 2.136 4.846 3.898 6.115l.341.247.409.297.001.001.001.001c1.244.9 2.204 1.594 2.204 3.123 0 1.28-.785 1.788-1.696 1.813-1.005.025-1.735-.805-1.735-1.847v-1.686a.191.191 0 0 0-.189-.194h-3.219c-.11 0-.188.084-.188.195v1.71c0 3.38 1.9 5.253 5.245 5.253 3.344 0 5.37-1.915 5.37-5.278 0-3.502-2.074-5.015-3.881-6.335l-.06-.044a42.858 42.858 0 0 0-.596-.428c-1.238-.88-2.388-1.697-2.388-2.969 0-1.262.8-1.855 1.727-1.855.998 0 1.704.771 1.704 1.788v1.49c0 .11.087.195.189.195h3.219c.11 0 .188-.084.188-.194V14.7c.008-3.32-1.994-5.227-5.237-5.244Zm11.563 0h.055c3.243.017 5.237 1.923 5.237 5.244v1.449c0 .11-.078.194-.188.194h-3.22a.191.191 0 0 1-.188-.194v-1.491c0-1.017-.706-1.788-1.704-1.788-.926 0-1.727.593-1.727 1.855 0 1.271 1.15 2.089 2.388 2.969.198.14.398.283.596.428l.06.044c1.808 1.32 3.881 2.833 3.881 6.335 0 3.363-2.026 5.278-5.37 5.278-3.345 0-5.245-1.872-5.245-5.252v-1.712c0-.11.079-.194.188-.194h3.22c.102 0 .188.084.188.195V24.5c0 1.042.73 1.872 1.735 1.847.91-.025 1.696-.534 1.696-1.813 0-1.53-.96-2.223-2.203-3.123-.134-.097-.272-.196-.411-.3l-.338-.244-.003-.002c-1.763-1.269-3.9-2.808-3.9-6.115 0-3.177 1.815-5.295 5.253-5.295Zm55.47 6.398v-1.618c0-2.465-1.9-4.405-4.083-4.405h-6.485c-.078 0-.141.068-.141.152v19.273c0 .084.063.152.141.152h3.172c.086 0 .141-.076.141-.152v-8.023h1.555c1.445 0 1.9.576 1.9 2.042v5.964c0 .093.071.152.141.152h3.274a.153.153 0 0 0 .149-.152v-5.854c0-2-.51-3.279-1.813-3.804 1.311-.576 2.049-1.728 2.049-3.727Zm-3.549.678c0 .804-.597 1.448-1.335 1.448h-2.41v-4.896h2.41c.738 0 1.335.644 1.335 1.44v2.008Zm-77.1-6.701h3.377c.063 0 .125.05.141.127l4.381 19.247c.04.11-.04.212-.141.212h-3.235c-.055 0-.126-.051-.141-.128l-.691-3.447h-4.036l-.69 3.447a.148.148 0 0 1-.142.127H29.05c-.094 0-.165-.101-.141-.211L33.32 9.958a.14.14 0 0 1 .142-.127Zm1.642 6.116-1.335 6.659h2.7l-1.334-6.659-.016.093-.015-.093ZM4.6 9.827H.062c-.034 0-.062.03-.062.066v4.385c0 .037.028.067.062.067h2.55c0 1.335-.903 1.718-2.09 1.801a.061.061 0 0 0-.056.063v1.689c0 .035.029.064.062.062 1.353-.068 2.365-.413 3.039-.985.733-.622 1.095-1.512 1.096-2.606V9.893c0-.037-.028-.067-.062-.067Z" clip-rule="evenodd"></path>
        </svg>
      </a>

      <ul>
        <li>
          <a href="#">Community</a>
          <ul class="submenu">
            <li>
              <div class="menu-info">
                <div>
                  <h6>Your work people are here</h6>
                  <p>Connect anonymously with professionals about work, pay, life and more.</p>
                </div>
                <a href="#" class="link open-signin-modal">Start using Glassdoor</a>
              </div>
              <div>
                <img src="https://www.glassdoor.com/assets/images/global-nav/locked-community.png" alt="Image" />
              </div>
            </li>
          </ul>
        </li>

        <li>
          <a href="#">Jobs</a>
          <ul class="submenu">
            <li>
              <div class="menu-info">
                <div>
                  <h6>Find the right job</h6>
                  <p>Millions of jobs. Search by what matters to you and find the one that's right for you.</p>
                </div>
                <a href="#" class="link open-signin-modal">Start using Glassdoor</a>
              </div>
              <div>
                <img src="https://www.glassdoor.com/assets/images/global-nav/locked-jobs.png" alt="Image" />
              </div>
            </li>
          </ul>
        </li>

        <li>
          <a href="#">Companies</a>
          <ul class="submenu">
            <li>
              <div class="menu-info">
                <div>
                  <h6>Read millions of reviews</h6>
                  <p>Read anonymous reviews on over 600,000 companies worldwide from the people that work there.</p>
                </div>
                <a href="#" class="link open-signin-modal">Start using Glassdoor</a>
              </div>
              <div>
                <img src="https://www.glassdoor.com/assets/images/global-nav/locked-companies.png" alt="Image" />
              </div>
            </li>
          </ul>
        </li>

        <li>
          <a href="#">Salaries</a>
          <ul class="submenu reverse">
            <li>
              <div class="menu-info">
                <div>
                  <h6>Compare salaries</h6>
                  <p>Are you paid fairly? Get a free, personalized salary estimate and compare with millions of salaries.</p>
                </div>
                <a href="#" class="link open-signin-modal">Start using Glassdoor</a>
              </div>
              <div>
                <img src="https://www.glassdoor.com/assets/images/global-nav/locked-salaries.png" alt="Image" />
              </div>
            </li>
          </ul>
        </li>

        <li>
          <a href="#">For Employers</a>
          <ul class="submenu reverse">
            <li>
              <a href="" class="menu-info">
                <h6>Unlock free employer profile</h6>
                <p>Find out how employers everywhere are using Glassdoor to attract the right talent.</p>
              </a>
              
              <a href="" class="menu-info">
                <h6>Sign in to employer center</h6>
                <p>Manage your company profile, view analytics, and respond to reviews.</p>
              </a>

              <a href="" class="menu-info">
                <h6>Employer branding</h6>
                <p>Cultivate your company brand and turn ideal candidates into great hires.</p>
              </a>
            </li>
            <li class="margin-top">
              <a href="" class="menu-info">
                <h6>Glassdoor for employers blog</h6>
                <p>Learn how to boost company culture and employee engagement to build an Employer Brand where top candidates want to work.</p>
              </a>
              <a href="" class="menu-info">
                <h6>Talk to sales</h6>
                <p>Talk with an Employer Brand Specialist to learn how to do more with an Enhanced Profile.</p>
              </a>
              <div>
                <img src="https://www.glassdoor.com/assets/images/global-nav/locked-community.png" alt="Image" />
              </div>
            </li>
          </ul>
        </li>
      </ul>

      <?php if(!is_set("email", $_SESSION["data"]) ){ ?>
      <a href="/login" class="signin open-signin-modal">
        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" fill="none" role="img" data-test="sign-in-svg">
          <path stroke="#fff" stroke-width="1.5" d="M2.998 12h14m0 0-4.5-4.5m4.5 4.5-4.5 4.5M7.771 8.28V5.75a2 2 0 0 1 2-2h9.48a2 2 0 0 1 2 2v11.995a2 2 0 0 1-2.006 2l-9.479-.026a2 2 0 0 1-1.995-2v-2.104"></path>
        </svg>
        <span>Sign in</span>
      </a>
      <?php } else { ?>
      <div class="mobile-header">
        <button type="button">
          <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 576 576" width="576" height="576" preserveAspectRatio="xMidYMid meet" style="width: 20px; height: 100%; transform: translate3d(0px, 0px, 0px); content-visibility: visible;"><defs><clipPath id="__lottie_element_302"><rect width="576" height="576" x="0" y="0"></rect></clipPath><g id="__lottie_element_310"><g transform="matrix(1,0,0,1,240,240)" opacity="1" style="display: block;"><g opacity="1" transform="matrix(1,0,0,1,0,0)"><path fill="rgb(0,10,180)" fill-opacity="1" d=" M0,-192 C105.96479797363281,-192 192,-105.96479797363281 192,0 C192,105.96479797363281 105.96479797363281,192 0,192 C-105.96479797363281,192 -192,105.96479797363281 -192,0 C-192,-105.96479797363281 -105.96479797363281,-192 0,-192z"></path></g><g opacity="1" transform="matrix(1,0,0,1,0,0)"></g></g></g><mask id="__lottie_element_310_1" mask-type="alpha"><use xlink:href="#__lottie_element_310"></use></mask></defs><g clip-path="url(#__lottie_element_302)"><g mask="url(#__lottie_element_310_1)" style="display: block;"><g transform="matrix(1,0,0,1,472,-96)" opacity="1"><g opacity="1" transform="matrix(1,0,0,1,0,0)"><path fill="rgb(76,214,129)" fill-opacity="1" d=" M0,-84 C46.35960006713867,-84 84,-46.35960006713867 84,0 C84,46.35960006713867 46.35960006713867,84 0,84 C-46.35960006713867,84 -84,46.35960006713867 -84,0 C-84,-46.35960006713867 -46.35960006713867,-84 0,-84z"></path></g><g opacity="1" transform="matrix(1,0,0,1,0,0)"></g></g></g><g transform="matrix(1,0,0,1,48,48)" opacity="1" style="display: block;"><g opacity="1" transform="matrix(1,0,0,1,-0.125,0.5)"><path fill="rgb(0,0,0)" fill-opacity="1" d=" M192,0 C298.03900146484375,0 384,85.96099853515625 384,192 C384,298.03900146484375 298.03900146484375,384 192,384 C85.96099853515625,384 0,298.03900146484375 0,192 C0,85.96099853515625 85.96099853515625,0 192,0z M192,36 C105.98100280761719,36 36,105.98100280761719 36,192 C36,278.0190124511719 105.98100280761719,348 192,348 C278.0190124511719,348 348,278.0190124511719 348,192 C348,105.98100280761719 278.0190124511719,36 192,36"></path></g></g><g transform="matrix(1,0,0,1,387.7720031738281,387.7720031738281)" opacity="1" style="display: block;"><g opacity="1" transform="matrix(1,0,0,1,0,0)"><path fill="rgb(0,0,0)" fill-opacity="1" d=" M25.45599937438965,0 C25.45599937438965,0 144.45599365234375,119 144.45599365234375,119 C144.45599365234375,119 119,144.45599365234375 119,144.45599365234375 C119,144.45599365234375 0,25.45599937438965 0,25.45599937438965 C0,25.45599937438965 25.45599937438965,0 25.45599937438965,0z"></path></g><g opacity="1" transform="matrix(1,0,0,1,0,0)"></g></g></g></svg></button>
        <button type="button">
          <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1152 1152" width="1152" height="1152" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px); content-visibility: visible;"><defs><clipPath id="__lottie_element_367"><rect width="1152" height="1152" x="0" y="0"></rect></clipPath></defs><g clip-path="url(#__lottie_element_367)"><g style="display: none;" transform="matrix(1,0,0,1,576,528.001953125)" opacity="0.00005750000001039646"><g opacity="1" transform="matrix(1,0,0,1,0,0)"><path fill="rgb(77,215,131)" fill-opacity="1" d=" M0,-168 C92.71920013427734,-168 168,-92.71920013427734 168,0 C168,92.71920013427734 92.71920013427734,168 0,168 C-92.71920013427734,168 -168,92.71920013427734 -168,0 C-168,-92.71920013427734 -92.71920013427734,-168 0,-168z"></path></g><g opacity="1" transform="matrix(1,0,0,1,0,0)"></g></g><g transform="matrix(1.0999943017959595,0,0,1.0999943017959595,338.4012451171875,361.00103759765625)" opacity="1" style="display: block;"><g opacity="1" transform="matrix(1,0,0,1,0,0)"><path fill="rgb(0,0,0)" fill-opacity="1" d=" M49.305999755859375,359.2969970703125 C18.503000259399414,321.3370056152344 0,272.6759948730469 0,219.62100219726562 C0,98.3280029296875 96.70600128173828,0 216,0 C335.29400634765625,0 432,98.3280029296875 432,219.62100219726562 C432,273.0039978027344 413.26800537109375,321.9389953613281 382.12200927734375,360 C377.1440124511719,349.26300048828125 371.1919860839844,339.08599853515625 364.3810119628906,329.5849914550781 C386.52899169921875,298.74200439453125 399.6000061035156,260.7340087890625 399.6000061035156,219.62100219726562 C399.6000061035156,116.52200317382812 317.39898681640625,32.94300079345703 216,32.94300079345703 C114.60099792480469,32.94300079345703 32.400001525878906,116.52200317382812 32.400001525878906,219.62100219726562 C32.400001525878906,260.45599365234375 45.29499816894531,298.2279968261719 67.1709976196289,328.9580078125 C60.32099914550781,338.4309997558594 54.32699966430664,348.5830078125 49.305999755859375,359.2969970703125z"></path></g><g opacity="1" transform="matrix(1,0,0,1,0,0)"></g></g><g transform="matrix(1,0,0,1,417.6099853515625,747.6099853515625)" opacity="1" style="display: block;"><g opacity="1" transform="matrix(1,0,0,1,0,0)"><path fill="rgb(0,0,0)" fill-opacity="1" d=" M315.3450012207031,33.834999084472656 C273.22100830078125,70.41899871826172 218.2209930419922,92.56300354003906 158.0489959716797,92.56300354003906 C97.51799774169922,92.56300354003906 42.220001220703125,70.15399932861328 0,33.17900085449219 C4.4670000076293945,21.43400001525879 10.208999633789062,10.317999839782715 17.058000564575195,0 C53.68899917602539,35.03900146484375 103.3550033569336,56.5629997253418 158.0489959716797,56.5629997253418 C212.43800354003906,56.5629997253418 261.8550109863281,35.27899932861328 298.4259948730469,0.5849999785423279 C305.2309875488281,10.930999755859375 310.927001953125,22.06999969482422 315.3450012207031,33.834999084472656z"></path></g><g opacity="1" transform="matrix(1,0,0,1,0,0)"></g></g><g transform="matrix(1,0,0,1,417.9570007324219,672)" opacity="1" style="display: block;"><g opacity="1" transform="matrix(1,0,0,1,0,0)"><path fill="rgb(0,0,0)" fill-opacity="1" d=" M0,108.61599731445312 C24.148000717163086,45.119998931884766 85.58000183105469,0 157.5489959716797,0 C229.76600646972656,0 291.3710021972656,45.430999755859375 315.3450012207031,109.27200317382812 C305.822998046875,117.54199981689453 295.64300537109375,125.0739974975586 284.8940124511719,131.7790069580078 C268.97198486328125,76.46399688720703 217.98599243164062,36 157.5489959716797,36 C97.30500030517578,36 46.45100021362305,76.20500183105469 30.35700035095215,131.2480010986328 C19.636999130249023,124.4990005493164 9.48799991607666,116.92500305175781 0,108.61599731445312z"></path></g><g opacity="1" transform="matrix(1,0,0,1,0,0)"></g></g><g transform="matrix(1,0,0,1,456.0050048828125,432)" opacity="1" style="display: block;"><g opacity="1" transform="matrix(1,0,0,1,0,0)"></g><g opacity="1" transform="matrix(1,0,0,1,0,0)"><path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4" stroke="rgb(0,0,0)" stroke-opacity="1" stroke-width="36" d=" M222,120 C222,178.8181610107422 178.8181610107422,222 120,222 C61.181846618652344,222 18,178.8181610107422 18,120 C18,61.181846618652344 61.181846618652344,18 120,18 C178.8181610107422,18 222,61.181846618652344 222,120 C222,120 222,120 222,120z"></path></g></g></g></svg>
        </button>
        <button type="button" class="open-menu">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" role="img">
            <g fill="currentColor" fill-rule="evenodd">
              <path d="M21 11H3a1 1 0 0 0 0 2h18a1 1 0 0 0 0-2ZM3 5h18a1 1 0 0 0 0-2H3a1 1 0 0 0 0 2ZM21 19H3a1 1 0 0 0 0 2h18a1 1 0 0 0 0-2Z"></path>
            </g>
          </svg>
        </button>

        <div class="login-modal mobile-menu">
          <div class="content">
            <div class="close-button">
              <button type="button" class="close-signin-modal">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24" role="img" aria-live="polite" aria-hidden="false" class="CloseIcon">
                  <path fill="currentColor" fill-rule="evenodd" d="M6.623 5.278a.95.95 0 1 0-1.345 1.345L10.656 12l-5.378 5.377a.95.95 0 1 0 1.345 1.345L12 13.344l5.377 5.378a.95.95 0 0 0 1.345-1.345L13.344 12l5.378-5.377a.95.95 0 0 0-1.345-1.345L12 10.656 6.623 5.278Z" clip-rule="evenodd"></path>
                </svg>
              </button>
            </div>
            <ul>
              <li><a href="">Community</a></li>
              <li><a href="">Jobs</a></li>
              <li><a href="">Companies</a></li>
              <li><a href="">Salaries</a></li>
            </ul>
          </div>
        </div>
      </div>
      <?php } ?>
    </div>
  </div>
</header>