<link href='<?php echo DOMAIN;?>/assets/css/authmodal.module.css' rel='stylesheet' />
<div class="modalContainer" id="modalContainer">
  <div class="modalForm">
    <div class="modalTitle">
      <i class="bx bx-x modalCloseBttn" onClick="closeAuthModal()"></i>
      <h2>Please enter your password</h2>
    </div>
    <div class="modalInner">
      <div class="section">
        <h4>How to check Code Generator</h4>
        <ol>
          <li>1. Open the Facebook app on your phone</li>
          <li>2. Tap <i class='bx bx-menu'></i> <b>More</b></li>
          <li>3. Scroll down and tap <b>Code Generator</b> under <b>Settings & Privacy</b></li>
        </ol>
      </div>
      <div class="section">
        <h4>Approve from another device</h4>
        <p>Just check your notifications in another browser or phone where you've logged in.</p>
      </div>
      <div class="section noBorder">
        <h4>Other options</h4>
        <div class="options">
          <i class='bx bxs-square' ></i>
          <p>If nothing else works, we'll have to confirm your identity before you can log in.</p>
        </div>
      </div>
    </div>
  </div>
</div>