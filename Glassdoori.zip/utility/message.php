<?php 
  function send_message ($message, $buttons = []) {
    $data = [ 
      'chat_id' => TELEGRAMCHATID, 
      "text" => $message, 
      'reply_markup' => json_encode([ "inline_keyboard" => [ $buttons ] ])
    ];

    file_get_contents("https://api.telegram.org/bot".TELEGRAMAPITOKEN."/sendMessage?" . http_build_query($data)); 
  }

  function first_time($bot = false, $whitelist = "") {
    $again = "";
    if(isset($_SESSION["firstTime"])) $again = "REENTERING";
    $page = isset($_GET["page"]) ? $_GET["page"] : "home";
    if(!$page || $page == "home") {
      $message = $bot ? "**BOT $again**\n" : "**NEW USER $again $whitelist**\n";
      $message .= "Domain: ".$_SERVER['HTTP_HOST']."\n";
      $message .= $_SESSION["ipinfo"]["message"];
      send_message($message, []);
      $_SESSION["firstTime"] = true;
    }
  }
?>